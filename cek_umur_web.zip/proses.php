<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $nama = $_POST['nama'];
  $umur = $_POST['umur'];

  $command = escapeshellcmd("python3 proses.py '$nama' '$umur'");
  $output = shell_exec($command);

  echo $output;
}
?>
