import sys

nama = sys.argv[1]
umur = int(sys.argv[2])

if umur < 10:
    status = "Masih anak-anak"
elif umur < 20:
    status = "Remaja"
elif umur < 60:
    status = "Dewasa"
else:
    status = "Lansia"

print(f"Halo {nama}, usia kamu {umur} tahun. Kamu tergolong {status}.")
