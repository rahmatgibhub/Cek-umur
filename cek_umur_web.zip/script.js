function kirimData() {
  let nama = document.getElementById('nama').value;
  let umur = document.getElementById('umur').value;

  fetch('proses.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: `nama=${nama}&umur=${umur}`
  })
  .then(response => response.text())
  .then(data => {
    document.getElementById('hasil').innerText = data;
  });
}
